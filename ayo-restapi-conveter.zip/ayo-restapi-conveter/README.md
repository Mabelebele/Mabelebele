# Ayo Rest API

## Overview

Technical Test Instructions
1. Create a Spring Boot application using rest API’s to do a conversions.
2. Convert Metric to imperial and vice versa. The API must cater for at least 5 conversions (include temperature conversion please).
3. Ensure that you have proper Unit and Integration testing that accompany the project.
4. Insomnia/Postman/Jmeter project with your RestAPI's.
5. Use the latest Angular to create a front end for your project. (Only if you have time)
6. Upload your project into your own GIT repository and share the project with us.
7. The project must be able to run in its own Docker environment
8. Build system must use Maven.
 
