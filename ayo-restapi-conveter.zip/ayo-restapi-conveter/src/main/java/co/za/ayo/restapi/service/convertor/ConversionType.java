package co.za.ayo.restapi.service.convertor;

public enum ConversionType{
    AREA,
    LENGTH,
    TEMPERATURE,
    VOLUME,
    WEIGHT
}
