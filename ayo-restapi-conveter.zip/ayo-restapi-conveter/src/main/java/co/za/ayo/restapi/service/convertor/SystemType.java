package co.za.ayo.restapi.service.convertor;

public enum SystemType {
    IMPERIAL,
    METRIC
}
