package co.za.ayo.restapi.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.Arrays;

@org.springframework.context.annotation.Configuration
public class RestConfiguration {
        @Bean
    public CorsFilter corsFilter() {
        final org.springframework.web.cors.CorsConfiguration restConfig = new org.springframework.web.cors.CorsConfiguration();

            restConfig.setAllowCredentials(false);
            restConfig.setAllowedOrigins(Arrays.asList("*"));
            restConfig.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
            restConfig.setAllowedHeaders(Arrays.asList("authorization", "content-type", "x-auth-token"));
            restConfig.setExposedHeaders(Arrays.asList("x-auth-token", "authorization"));
            UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
            source.registerCorsConfiguration("/**", restConfig);

        return new CorsFilter(source);
    }
}
