package co.za.ayo.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AyoRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AyoRestApiApplication.class, args);
	}

}
